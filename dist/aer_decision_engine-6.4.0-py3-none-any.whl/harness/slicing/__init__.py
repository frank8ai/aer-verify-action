"""Causal execution slicing package."""
